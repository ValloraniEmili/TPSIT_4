
package corsa;

/**
 * Giudice Ã¨ la classe che determina il vincitore
 * @author Andrea Vallorani
 */
public class Giudice extends Thread{
    
    private Pista pista;
    private String vincitore = "";
    private int i=0;
    private String v[]= new String[10];
    
    public Giudice(Pista p){
        this.pista = p;
    }
    
    public void run(){
        Atleta a1 = new Atleta("Ducati ",this.pista.Atleta1,this);                                       
        Atleta a2 = new Atleta("Suzuki",this.pista.Atleta2,this);
        Atleta a3 = new Atleta("Kawasaki",this.pista.Atleta3,this);                                       
        a1.start();
        a2.start();
        a3.start();
        this.pista.statoGara.setText("Gara iniziata");
        try{
            a1.join();
            a2.join();
            a3.join();
        }
        catch(Exception e){
        }
           this.pista.statoGara.setText("Gara conclusa, ha vinto "+this.getVincitore());
           Classifi();
            this.pista.bottoneAvvio.setEnabled(true);
        
    }
    
    synchronized public void hoFinito(String nomeAtleta){
        if(this.vincitore==""){
            this.vincitore = nomeAtleta;
       }
        this.v[i]=nomeAtleta;
        i++;
    }
    public String getVincitore(){
        return this.vincitore;
    }
    public void Classifi(){
        Classifica f=new Classifica();
        f.setVisible(true);
        f.setLocationRelativeTo(null);
        f.primo.setText("1."+v[0]);
        f.secondo.setText("2."+v[1]);
        f.terzo.setText("3."+v[2]);
        }
      
}

    